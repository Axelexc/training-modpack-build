@echo off
setlocal
where rustc
rustc --version
where cargo
cargo --version
where cargo-skyline
cargo-skyline --version
pause
