ULTIMATE TRAINING MODPACK - DI MIXUP / SMASH ULTIMATE 13.0.4

This source tree is based on UltimateTrainingModpack 7.0.0 and contains the DI Mixup modification.

COMPATIBILITY CHECK
- Super Smash Bros. Ultimate: 13.0.4
- Ultimate Training Modpack 7.0.0: officially added support for SSBU 13.0.4
- ARCropolis 4.0.8: the 4.0.8 release is the ARCropolis line used with SSBU 13.0.4
- Do NOT replace this source with Training Modpack 7.1.x if you are staying on Smash 13.0.4; 7.1.x moved the official project to Smash 13.0.5.

BUILD
1. Open this folder in VS Code.
2. Make sure `cargo` and `cargo-skyline` work in a new terminal.
3. Run BUILD_13.0.4.bat.
4. The compiled plugin will be:
   target\\aarch64-skyline-switch\\release\\libtraining_modpack.nro

INSTALLATION TARGET
The resulting NRO belongs here:
   atmosphere\\contents\\01006A800016E000\\romfs\\skyline\\plugins\\libtraining_modpack.nro

The plugin prerequisites remain required:
- libnro_hook.nro
- libparam_hook.nro (13.0.4-compatible build)
- Skyline

IMPORTANT
This package is source code, not a precompiled NRO. The custom DI Mixup code must be compiled from this source; copying the official 7.0.0 binary would remove the custom source changes.
