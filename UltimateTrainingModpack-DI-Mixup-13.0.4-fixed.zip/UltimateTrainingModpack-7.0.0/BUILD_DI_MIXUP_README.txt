DI Mixup - Smash Ultimate 13.0.4

1. Keep your game on 13.0.4.
2. Keep ARCropolis 4.0.8 for this setup.
3. Open this folder (the one containing Cargo.toml).
4. Run BUILD_13.0.4.bat.
5. The script now searches recursively for ANY generated .nro instead of assuming the filename/path.
6. If an .nro is found under target, it is copied to:
   target\aarch64-skyline-switch\release\libtraining_modpack.nro

If it still says no NRO was found, run:
   dir /s /b target\*.nro

Then send the complete output. The previous script was failing only because its final check assumed one exact output path/name.
