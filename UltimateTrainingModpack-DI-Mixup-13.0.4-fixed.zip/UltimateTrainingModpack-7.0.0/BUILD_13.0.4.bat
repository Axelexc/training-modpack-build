@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ==================================================
echo Ultimate Training Modpack - DI Mixup
echo Target: Super Smash Bros. Ultimate 13.0.4
echo ==================================================
echo.

echo [1/4] Checking tools...
where cargo >nul 2>&1 || goto :nocargo
where cargo-skyline >nul 2>&1 || goto :noskyline
cargo --version
cargo-skyline --version

echo.
echo [2/4] Updating Skyline standard library...
cargo-skyline skyline update-std
if errorlevel 1 goto :updaterror

echo.
echo [3/4] Building NRO...
set "RUSTFLAGS=-g"
cargo-skyline skyline build --release
if errorlevel 1 goto :builderror

echo.
echo [4/4] Locating generated NRO...
set "NRO="
for /r "target" %%F in (*.nro) do (
    if not defined NRO set "NRO=%%F"
)
if not defined NRO goto :nooutput

echo Found:
echo !NRO!
if /I not "!NRO!"=="%CD%\target\aarch64-skyline-switch\release\libtraining_modpack.nro" (
    echo Copying it to the standard output path...
    if not exist "target\aarch64-skyline-switch\release" mkdir "target\aarch64-skyline-switch\release"
    copy /Y "!NRO!" "target\aarch64-skyline-switch\release\libtraining_modpack.nro" >nul
)
if not exist "target\aarch64-skyline-switch\release\libtraining_modpack.nro" goto :copyerror

echo.
echo ==================================================
echo BUILD SUCCESSFUL
echo Output:
echo %CD%\target\aarch64-skyline-switch\release\libtraining_modpack.nro
echo ==================================================
echo.
echo For Smash 13.0.4 use ARCropolis 4.0.8.
echo Install the NRO in:
echo atmosphere\contents\01006A800016E000\romfs\skyline\plugins\
echo.
pause
exit /b 0

:nocargo
echo ERROR: cargo was not found in PATH.
echo Install Rust/rustup, then restart the terminal.
goto :fail

:noskyline
echo ERROR: cargo-skyline was not found in PATH.
echo Install it with: cargo install cargo-skyline
goto :fail

:updaterror
echo ERROR: skyline update-std failed.
goto :fail

:builderror
echo ERROR: the Skyline build command failed.
echo Scroll up and send me the compiler error if this happens.
goto :fail

:nooutput
echo ERROR: cargo-skyline returned success, but no .nro was found anywhere under:
echo %CD%\target
echo.
echo Run this command manually and send me the result:
echo dir /s /b target\*.nro
goto :fail

:copyerror
echo ERROR: an NRO was found, but it could not be copied to the expected output path.
goto :fail

:fail
pause
exit /b 1
